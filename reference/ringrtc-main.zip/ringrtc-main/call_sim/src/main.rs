//
// Copyright 2023 Signal Messenger, LLC
// SPDX-License-Identifier: AGPL-3.0-only
//

mod audio;
mod common;
mod config;
mod docker;
mod report;
mod test;

use std::{
    env,
    fs::File,
    path::Path,
    time::{Duration, SystemTime},
};

use anyhow::Result;
use clap::Parser;
use common::ClientProfile;
use hex::FromHex;
use itertools::{Itertools, iproduct};

use crate::{
    common::{
        AudioAnalysisMode, AudioConfig, BurstLength, CallConfig, CallProfile::DeterministicLoss,
        ChartDimension, GroupConfig, NetworkConfig, NetworkConfigWithOffset, NetworkProfile,
        RelayServerConfig, SummaryReportColumns, TestCaseConfig, VideoConfig,
    },
    docker::{build_images, clean_network, clean_up},
    test::{CallTypeConfig, Test},
};

fn compile_time_root_directory() -> &'static std::ffi::OsStr {
    std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
        .parent() // ringrtc
        .unwrap()
        .as_os_str()
}

#[derive(Parser, Debug)]
struct Args {
    /// Specifies which tests to run.
    test_sets: Vec<String>,

    /// Specifies path to the root of the ringrtc directory.
    /// Usually relative when provided on the command line.
    #[arg(long, default_value = compile_time_root_directory())]
    root: String,

    /// If set, specifies the output directory for artifacts, relative to the root. Otherwise
    /// a `call_sim/test_results` directory will be created on the provided root.
    #[arg(long, default_value = "call_sim/test_results")]
    output_dir: String,

    /// If set, specifies the directory where reference media can be found, relative to the
    /// root directory. Otherwise the `call_sim/media` directory will be assumed.
    #[arg(long, default_value = "call_sim/media")]
    media_dir: String,

    /// If set, specifies the directory where misc data can be found, relative to the
    /// root directory. Otherwise the `call_sim/data` directory will be assumed.
    #[arg(long, default_value = "call_sim/data")]
    data_dir: String,

    /// Builds all dependent docker images.
    #[arg(short, long)]
    build: bool,

    /// Cleans up containers and networks before running (in case prior runs failed to do so).
    #[arg(short, long)]
    clean: bool,

    #[arg(long)]
    client_profile_dir: Option<String>,

    /// Specify a group from the group list in the client_profile file
    /// If None, then uses the first group in the list
    #[arg(long)]
    group_name: Option<String>,

    /// Run `perf record` on the clients
    #[arg(long)]
    profile: bool,

    /// Skip building the visqol_mos container. This build can be slow, and it's only needed for
    /// certain analyses.
    #[arg(long)]
    skip_visqol_mos_build: bool,
}

// Set these two values when running call sim group calls. The Auth Key is used to generate profiles
// and the SFU url points to the SFU connect to
const SFU_URL: &str = "https://sfu.test.voip.signal.org";
fn group_auth_key_gen() -> [u8; 32] {
    <[u8; 32]>::from_hex("deaddeaddeaddeaddeaddeaddeaddeaddeaddeaddeaddeaddeaddeaddeaddead")
        .unwrap()
}

/// This is a minimal example of a test.
async fn run_minimal_example(test: &mut Test) -> Result<()> {
    // Optional: Pre-process sounds that you will use. This will generate a spectrogram
    // and calculate a reference MOS for each sound. Normally, this might be useful,
    // but sometimes you just want to run a test and don't need this information.
    // Here we are leaving out the `silence` sound since there is no point to get a
    // MOS value for it.
    test.preprocess_sounds(vec!["normal_phrasing"]).await?;

    // Run a test with a `default` config. Here, we will use 30-second calls and specify
    // a default call configuration. The test will actually run one or more test cases,
    // each a permutation of the call configuration, sound pairs, and network profiles.
    test.run(
        GroupConfig {
            group_name: "minimal_example".to_string(),
            ..Default::default()
        },
        vec![TestCaseConfig {
            test_case_name: "default".to_string(),
            // client_a is sending a set of spoken phrases, which will be analyzed from
            // client_b's perspective.
            client_a_config: CallConfig::default().with_audio_input_name("normal_phrasing"),
            // In this case, client_b is sending recorded silence (the default).
            client_b_config: CallConfig::default(),
            ..Default::default()
        }],
        // Finally, the network profiles to test against can be specified. The `None`
        // profile won't try to emulate anything, which is useful when establishing
        // baseline measurements.
        vec![NetworkProfile::None],
    )
    .await?;

    Ok(())
}

/// This is a test set to test the "normal phrasing" audio (and video) over various network
/// profiles. This sets packet time to 60ms to align with our production configuration.
async fn run_baseline(test: &mut Test, with_video: bool, with_dred: bool) -> Result<()> {
    let video = if with_video {
        VideoConfig {
            input_name: Some("ConferenceMotion_50fps@1280x720".to_string()),
            ..Default::default()
        }
    } else {
        Default::default()
    };

    test.run(
        GroupConfig {
            group_name: match (with_video, with_dred) {
                (false, false) => "baseline".to_string(),
                (true, false) => "baseline_with_video".to_string(),
                (false, true) => "baseline_with_dred".to_string(),
                (true, true) => "baseline_with_video_and_dred".to_string(),
            },
            // Show all the different measurements in the summary columns. Hide video.
            summary_report_columns: SummaryReportColumns {
                show_visqol_mos_speech: true,
                show_visqol_mos_audio: true,
                show_pesq_mos: true,
                show_plc_mos: true,
                show_video: with_video,
                show_send_stats: !with_dred,
                show_dred_stats: with_dred,
                ..Default::default()
            },
            ..Default::default()
        },
        vec![TestCaseConfig {
            test_case_name: "ptime-60".to_string(),
            client_a_config: CallConfig {
                audio: AudioConfig {
                    input_name: "normal_phrasing".to_string(),
                    initial_packet_size_ms: 60,
                    // We don't look at analysis from client_a's point of view, so there
                    // is no need to generate anything for it.
                    generate_spectrogram: false,
                    enable_fec: !with_dred,
                    dred_duration: if with_dred { 100 } else { 0 },
                    dnn_weights_path: if with_dred {
                        "/data/deep_plc-dred-weights.bin".to_string()
                    } else {
                        "".to_string()
                    },
                    ..Default::default()
                },
                video: video.clone(),
                ..Default::default()
            },
            client_b_config: CallConfig {
                audio: AudioConfig {
                    input_name: "normal_phrasing".to_string(),
                    initial_packet_size_ms: 60,
                    // Calculate all mos values for these audio tests.
                    visqol_speech_analysis: true,
                    visqol_audio_analysis: true,
                    pesq_speech_analysis: true,
                    plc_speech_analysis: true,
                    enable_fec: !with_dred,
                    dred_duration: if with_dred { 100 } else { 0 },
                    dnn_weights_path: if with_dred {
                        "/data/deep_plc-dred-weights.bin".to_string()
                    } else {
                        "".to_string()
                    },
                    ..Default::default()
                },
                video,
                ..Default::default()
            },
            // Run 3 iterations of each test to get an average to help contain the
            // non-deterministic behavior of the tests.
            iterations: 3,
            ..Default::default()
        }],
        vec![
            NetworkProfile::Default,
            NetworkProfile::Moderate,
            NetworkProfile::International,
            NetworkProfile::SpikyLoss,
            NetworkProfile::LimitedBandwidth(300),
            NetworkProfile::LimitedBandwidth(100),
            NetworkProfile::LimitedBandwidth(50),
            NetworkProfile::LimitedBandwidth(25),
            NetworkProfile::SimpleLoss(10),
            NetworkProfile::SimpleLoss(20),
            NetworkProfile::SimpleLoss(30),
            NetworkProfile::SimpleLoss(40),
            NetworkProfile::SimpleLoss(50),
        ],
    )
    .await?;

    Ok(())
}

/// Test 60ms ptime over a range of loss using various bursty loss profiles.
async fn run_bursty_loss_test(test: &mut Test, with_video: bool, with_dred: bool) -> Result<()> {
    let video = if with_video {
        VideoConfig {
            input_name: Some("ConferenceMotion_50fps@1280x720".to_string()),
            ..Default::default()
        }
    } else {
        Default::default()
    };

    test.run(
        GroupConfig {
            group_name: match (with_video, with_dred) {
                (false, false) => "bursty_loss_test".to_string(),
                (true, false) => "bursty_loss_test_with_video".to_string(),
                (false, true) => "bursty_loss_test_with_dred".to_string(),
                (true, true) => "bursty_loss_test_with_video_and_dred".to_string(),
            },
            // Show all the different measurements in the summary columns. Hide video.
            summary_report_columns: SummaryReportColumns {
                show_visqol_mos_speech: true,
                show_visqol_mos_audio: true,
                show_pesq_mos: true,
                show_plc_mos: true,
                show_video: with_video,
                show_send_stats: !with_dred,
                show_dred_stats: with_dred,
                ..Default::default()
            },
            ..Default::default()
        },
        vec![TestCaseConfig {
            test_case_name: "ptime-60".to_string(),
            client_a_config: CallConfig {
                audio: AudioConfig {
                    input_name: "normal_phrasing".to_string(),
                    initial_packet_size_ms: 60,
                    // We don't look at analysis from client_a's point of view, so there
                    // is no need to generate anything for it.
                    generate_spectrogram: false,
                    enable_fec: !with_dred,
                    dred_duration: if with_dred { 100 } else { 0 },
                    dnn_weights_path: if with_dred {
                        "/data/deep_plc-dred-weights.bin".to_string()
                    } else {
                        "".to_string()
                    },
                    ..Default::default()
                },
                video: video.clone(),
                ..Default::default()
            },
            client_b_config: CallConfig {
                audio: AudioConfig {
                    input_name: "normal_phrasing".to_string(),
                    initial_packet_size_ms: 60,
                    // Calculate all mos values for these audio tests.
                    visqol_speech_analysis: true,
                    visqol_audio_analysis: true,
                    pesq_speech_analysis: true,
                    plc_speech_analysis: true,
                    enable_fec: !with_dred,
                    dred_duration: if with_dred { 100 } else { 0 },
                    dnn_weights_path: if with_dred {
                        "/data/deep_plc-dred-weights.bin".to_string()
                    } else {
                        "".to_string()
                    },
                    ..Default::default()
                },
                video,
                ..Default::default()
            },
            ..Default::default()
        }],
        vec![
            NetworkProfile::Default,
            NetworkProfile::BurstyLoss(10, BurstLength::Short),
            NetworkProfile::BurstyLoss(10, BurstLength::Medium),
            NetworkProfile::BurstyLoss(10, BurstLength::Long),
            NetworkProfile::BurstyLoss(10, BurstLength::VeryLong),
            NetworkProfile::BurstyLoss(20, BurstLength::Short),
            NetworkProfile::BurstyLoss(20, BurstLength::Medium),
            NetworkProfile::BurstyLoss(20, BurstLength::Long),
            NetworkProfile::BurstyLoss(20, BurstLength::VeryLong),
            NetworkProfile::BurstyLoss(30, BurstLength::Short),
            NetworkProfile::BurstyLoss(30, BurstLength::Medium),
            NetworkProfile::BurstyLoss(30, BurstLength::Long),
            NetworkProfile::BurstyLoss(30, BurstLength::VeryLong),
            NetworkProfile::BurstyLoss(40, BurstLength::Short),
            NetworkProfile::BurstyLoss(40, BurstLength::Medium),
            NetworkProfile::BurstyLoss(40, BurstLength::Long),
            NetworkProfile::BurstyLoss(40, BurstLength::VeryLong),
            NetworkProfile::BurstyLoss(50, BurstLength::Short),
            NetworkProfile::BurstyLoss(50, BurstLength::Medium),
            NetworkProfile::BurstyLoss(50, BurstLength::Long),
            NetworkProfile::BurstyLoss(50, BurstLength::VeryLong),
        ],
    )
    .await?;

    Ok(())
}

/// Test 20ms and 60ms ptime over a range of deterministic loss, with and without dtx.
/// Note that deterministic loss is better than the SimpleLoss network profile, but
/// it is still not completely reliable.
async fn run_deterministic_loss_test(
    test: &mut Test,
    with_video: bool,
    with_dred: bool,
) -> Result<()> {
    let video = if with_video {
        VideoConfig {
            input_name: Some("ConferenceMotion_50fps@1280x720".to_string()),
            ..Default::default()
        }
    } else {
        Default::default()
    };
    let ptime_values = [20, 60];
    let dtx_values = [false, true];
    let loss_values = (0..=50).step_by(10);

    let test_cases = iproduct!(dtx_values, ptime_values, loss_values)
        .map(
            |(enable_dtx, initial_packet_size_ms, loss)| TestCaseConfig {
                test_case_name: format!("ptime-{initial_packet_size_ms}_dtx-{enable_dtx}_{loss}"),
                length_seconds: 30,
                client_a_config: CallConfig {
                    audio: AudioConfig {
                        input_name: "normal_phrasing".to_string(),
                        initial_packet_size_ms,
                        enable_dtx,
                        generate_spectrogram: false,
                        enable_fec: !with_dred,
                        dred_duration: if with_dred { 100 } else { 0 },
                        dnn_weights_path: if with_dred {
                            "/data/deep_plc-dred-weights.bin".to_string()
                        } else {
                            "".to_string()
                        },
                        ..Default::default()
                    },
                    video: video.clone(),
                    profile: DeterministicLoss(loss),
                    ..Default::default()
                },
                client_b_config: CallConfig {
                    audio: AudioConfig {
                        input_name: "normal_phrasing".to_string(),
                        initial_packet_size_ms,
                        enable_dtx,
                        visqol_speech_analysis: true,
                        visqol_audio_analysis: true,
                        pesq_speech_analysis: true,
                        plc_speech_analysis: true,
                        enable_fec: !with_dred,
                        dred_duration: if with_dred { 100 } else { 0 },
                        dnn_weights_path: if with_dred {
                            "/data/deep_plc-dred-weights.bin".to_string()
                        } else {
                            "".to_string()
                        },
                        ..Default::default()
                    },
                    video: video.clone(),
                    profile: DeterministicLoss(loss),
                    ..Default::default()
                },
                iterations: 3,
                ..Default::default()
            },
        )
        .collect::<Vec<_>>();

    test.run(
        GroupConfig {
            group_name: match (with_video, with_dred) {
                (false, false) => "deterministic_loss_test".to_string(),
                (true, false) => "deterministic_loss_test_with_video".to_string(),
                (false, true) => "deterministic_loss_test_with_dred".to_string(),
                (true, true) => "deterministic_loss_test_with_video_and_dred".to_string(),
            },
            summary_report_columns: SummaryReportColumns {
                show_visqol_mos_speech: true,
                show_visqol_mos_audio: true,
                show_pesq_mos: true,
                show_plc_mos: true,
                show_video: with_video,
                show_send_stats: !with_dred,
                show_dred_stats: with_dred,
                ..Default::default()
            },
            ..Default::default()
        },
        test_cases,
        vec![NetworkProfile::None],
    )
    .await?;

    Ok(())
}

/// Here is a test to run without a TURN server, with a TURN server, and forcing the use of a
/// TURN server over UDP, and then forcing the use of a TURN server over TCP.
/// Notes:
///  - The default username and password are already set by default
///  - Both clients will use the TURN server (in this test)
///  - The `turn` domain name should resolve by Docker to the container with the name `turn`
async fn run_relay_tests(test: &mut Test) -> Result<()> {
    test.run(
        GroupConfig {
            group_name: "relay_tests".to_string(),
            summary_report_columns: SummaryReportColumns {
                show_visqol_mos_audio: false,
                show_video: false,
                ..Default::default()
            },
            chart_dimensions: vec![ChartDimension::MosSpeech],
            ..Default::default()
        },
        vec![
            TestCaseConfig {
                test_case_name: "no_relay".to_string(),
                client_a_config: CallConfig {
                    audio: AudioConfig {
                        input_name: "normal_phrasing".to_string(),
                        initial_packet_size_ms: 60,
                        ..Default::default()
                    },
                    ..Default::default()
                },
                client_b_config: CallConfig {
                    audio: AudioConfig {
                        input_name: "normal_phrasing".to_string(),
                        initial_packet_size_ms: 60,
                        ..Default::default()
                    },
                    ..Default::default()
                },
                ..Default::default()
            },
            TestCaseConfig {
                test_case_name: "with_relay".to_string(),
                client_a_config: CallConfig {
                    relay_servers: RelayServerConfig {
                        urls: vec![
                            "stun:turn".to_string(),
                            "turn:turn".to_string(),
                            "turn:turn:80?transport=tcp".to_string(),
                        ],
                        ..Default::default()
                    },
                    start_turn_server: true,
                    audio: AudioConfig {
                        input_name: "normal_phrasing".to_string(),
                        initial_packet_size_ms: 60,
                        ..Default::default()
                    },
                    ..Default::default()
                },
                client_b_config: CallConfig {
                    relay_servers: RelayServerConfig {
                        urls: vec![
                            "stun:turn".to_string(),
                            "turn:turn".to_string(),
                            "turn:turn:80?transport=tcp".to_string(),
                        ],
                        ..Default::default()
                    },
                    start_turn_server: true,
                    audio: AudioConfig {
                        input_name: "normal_phrasing".to_string(),
                        initial_packet_size_ms: 60,
                        ..Default::default()
                    },
                    ..Default::default()
                },
                ..Default::default()
            },
            TestCaseConfig {
                test_case_name: "force_udp_relay".to_string(),
                client_a_config: CallConfig {
                    relay_servers: RelayServerConfig {
                        urls: vec!["turn:turn".to_string()],
                        ..Default::default()
                    },
                    start_turn_server: true,
                    force_relay: true,
                    audio: AudioConfig {
                        input_name: "normal_phrasing".to_string(),
                        initial_packet_size_ms: 60,
                        ..Default::default()
                    },
                    ..Default::default()
                },
                client_b_config: CallConfig {
                    relay_servers: RelayServerConfig {
                        urls: vec!["turn:turn".to_string()],
                        ..Default::default()
                    },
                    start_turn_server: true,
                    force_relay: true,
                    audio: AudioConfig {
                        input_name: "normal_phrasing".to_string(),
                        initial_packet_size_ms: 60,
                        ..Default::default()
                    },
                    ..Default::default()
                },
                ..Default::default()
            },
            TestCaseConfig {
                test_case_name: "force_tcp_relay".to_string(),
                client_a_config: CallConfig {
                    relay_servers: RelayServerConfig {
                        urls: vec!["turn:turn:80?transport=tcp".to_string()],
                        ..Default::default()
                    },
                    start_turn_server: true,
                    force_relay: true,
                    audio: AudioConfig {
                        input_name: "normal_phrasing".to_string(),
                        initial_packet_size_ms: 60,
                        ..Default::default()
                    },
                    ..Default::default()
                },
                client_b_config: CallConfig {
                    relay_servers: RelayServerConfig {
                        urls: vec!["turn:turn:80?transport=tcp".to_string()],
                        ..Default::default()
                    },
                    start_turn_server: true,
                    force_relay: true,
                    audio: AudioConfig {
                        input_name: "normal_phrasing".to_string(),
                        initial_packet_size_ms: 60,
                        ..Default::default()
                    },
                    ..Default::default()
                },
                ..Default::default()
            },
        ],
        vec![NetworkProfile::None],
    )
    .await?;

    Ok(())
}

/// Exercise TURN relay servers with a long (30-minute) test. Specify the relay server
/// credentials to use and adjust the length and iterations to desired values. This will
/// send both audio and video but will not save the received data nor perform any
/// analysis on the media.
async fn run_turn_long_tests(test: &mut Test) -> Result<()> {
    // Define the relay server configuration asymmetrically for both clients.
    let relay_urls = vec!["<add one or more relay servers here>".to_string()];
    let relay_urls_with_ips = vec!["<add one or more relay servers here>".to_string()];
    let relay_username = "<add username here>".to_string();
    let relay_password = "<add password here>".to_string();
    let relay_hostname = "<add hostname here>".to_string();

    test.run(
        GroupConfig {
            group_name: "turn_long_tests".to_string(),
            summary_report_columns: SummaryReportColumns::none(),
            ..Default::default()
        },
        vec![TestCaseConfig {
            test_case_name: "force_relay_with_video".to_string(),
            length_seconds: 1800,
            client_a_config: CallConfig {
                relay_servers: RelayServerConfig {
                    username: relay_username.clone(),
                    password: relay_password.clone(),
                    urls: relay_urls.clone(),
                    urls_with_ips: relay_urls_with_ips.clone(),
                    hostname: Some(relay_hostname.clone()),
                },
                force_relay: true,
                audio: AudioConfig {
                    input_name: "normal_phrasing".to_string(),
                    generate_spectrogram: false,
                    initial_packet_size_ms: 60,
                    visqol_speech_analysis: false,
                    visqol_audio_analysis: false,
                    pesq_speech_analysis: false,
                    plc_speech_analysis: false,
                    ..Default::default()
                },
                video: VideoConfig {
                    input_name: Some("ConferenceMotion_50fps@1280x720".to_string()),
                    ..Default::default()
                },
                ..Default::default()
            },
            client_b_config: CallConfig {
                relay_servers: RelayServerConfig {
                    username: relay_username,
                    password: relay_password,
                    urls: relay_urls,
                    urls_with_ips: relay_urls_with_ips,
                    hostname: Some(relay_hostname),
                },
                force_relay: true,
                audio: AudioConfig {
                    input_name: "normal_phrasing".to_string(),
                    generate_spectrogram: false,
                    initial_packet_size_ms: 60,
                    visqol_speech_analysis: false,
                    visqol_audio_analysis: false,
                    pesq_speech_analysis: false,
                    plc_speech_analysis: false,
                    ..Default::default()
                },
                video: VideoConfig {
                    input_name: Some("ConferenceMotion_50fps@1280x720".to_string()),
                    ..Default::default()
                },
                ..Default::default()
            },
            save_media_files: false,
            iterations: 4,
            ..Default::default()
        }],
        vec![NetworkProfile::None],
    )
    .await?;

    Ok(())
}

/// A test that sends video.
async fn run_video_send_over_bandwidth(test: &mut Test) -> Result<()> {
    test.preprocess_sounds(vec!["normal_phrasing"]).await?;

    test.run(
        GroupConfig {
            group_name: "video_send_over_bandwidth".to_string(),
            chart_dimensions: vec![ChartDimension::MosSpeech],
            ..Default::default()
        },
        vec![TestCaseConfig {
            test_case_name: "video".to_string(),
            client_a_config: CallConfig {
                video: VideoConfig {
                    // This will expect a file named "ConferenceMotion_50fps@1280x720.mp4" in the media directory.
                    // The dimensions are important, because the converted video only contains raw frame data.
                    // (This particular video *is* 50fps, but the CLI hardcodes 30fps for both send and receive.)
                    input_name: Some("ConferenceMotion_50fps@1280x720".to_string()),
                    ..Default::default()
                },
                ..CallConfig::default()
            }
            .with_audio_input_name("normal_phrasing"),
            client_b_config: CallConfig::default().with_audio_input_name("normal_phrasing"),
            ..Default::default()
        }],
        vec![
            NetworkProfile::None,
            NetworkProfile::LimitedBandwidth(2000),
            NetworkProfile::LimitedBandwidth(1500),
            NetworkProfile::LimitedBandwidth(1250),
            NetworkProfile::LimitedBandwidth(1000),
            NetworkProfile::LimitedBandwidth(750),
            NetworkProfile::LimitedBandwidth(500),
            NetworkProfile::LimitedBandwidth(250),
            NetworkProfile::LimitedBandwidth(125),
            NetworkProfile::LimitedBandwidth(100),
            NetworkProfile::LimitedBandwidth(75),
            NetworkProfile::LimitedBandwidth(50),
        ],
    )
    .await?;

    Ok(())
}

/// Bidirectional video test comparing the vp8 and vp9 video codecs.
async fn run_video_compare_vp8_vs_vp9(test: &mut Test, bitrate_values: &Vec<u16>) -> Result<()> {
    let mut test_cases = Vec::new();

    for bitrate in bitrate_values {
        test_cases.push(TestCaseConfig {
            test_case_name: format!("vp8_{}", bitrate),
            client_a_config: CallConfig {
                audio: AudioConfig {
                    input_name: "normal_phrasing".to_string(),
                    ..Default::default()
                },
                video: VideoConfig {
                    input_name: Some("ConferenceMotion_50fps@1280x720".to_string()),
                    ..Default::default()
                },
                allowed_bitrate_kbps: *bitrate,
                ..Default::default()
            },
            client_b_config: CallConfig {
                audio: AudioConfig {
                    input_name: "normal_phrasing".to_string(),
                    ..Default::default()
                },
                video: VideoConfig {
                    input_name: Some("ConferenceMotion_50fps@1280x720".to_string()),
                    ..Default::default()
                },
                allowed_bitrate_kbps: *bitrate,
                ..Default::default()
            },
            ..Default::default()
        });

        test_cases.push(TestCaseConfig {
            test_case_name: format!("vp9_{}", bitrate),
            client_a_config: CallConfig {
                audio: AudioConfig {
                    input_name: "normal_phrasing".to_string(),
                    ..Default::default()
                },
                video: VideoConfig {
                    input_name: Some("ConferenceMotion_50fps@1280x720".to_string()),
                    enable_vp9: true,
                },
                allowed_bitrate_kbps: *bitrate,
                ..Default::default()
            },
            client_b_config: CallConfig {
                audio: AudioConfig {
                    input_name: "normal_phrasing".to_string(),
                    ..Default::default()
                },
                video: VideoConfig {
                    input_name: Some("ConferenceMotion_50fps@1280x720".to_string()),
                    enable_vp9: true,
                },
                allowed_bitrate_kbps: *bitrate,
                ..Default::default()
            },
            ..Default::default()
        });
    }

    test.run(
        GroupConfig {
            group_name: "video_compare_vp8_vs_vp9".to_string(),
            chart_dimensions: vec![ChartDimension::MosSpeech],
            ..Default::default()
        },
        test_cases,
        vec![NetworkProfile::Default],
    )
    .await?;

    Ok(())
}

/// Test the scenario with changing bandwidth over one minute intervals:
/// 1 minute unlimited -> 1 minute 50kbps -> 1 minute 25kbps -> 1 minute unlimited
///
/// Uses a 12-second reference audio file so that the resulting 240-second session recording
/// can be chopped evenly and MOS calculated for each 12-second audio segment.
async fn run_changing_bandwidth_audio_test(test: &mut Test, with_dred: bool) -> Result<()> {
    let test_cases = [20, 60, 120].map(|initial_packet_size_ms| TestCaseConfig {
        test_case_name: format!("ptime_{initial_packet_size_ms}"),
        length_seconds: 240,
        client_a_config: CallConfig {
            audio: AudioConfig {
                input_name: "normal_12s".to_string(),
                initial_packet_size_ms,
                generate_spectrogram: false,
                enable_fec: !with_dred,
                dred_duration: if with_dred { 100 } else { 0 },
                dnn_weights_path: if with_dred {
                    "/data/deep_plc-dred-weights.bin".to_string()
                } else {
                    "".to_string()
                },
                ..Default::default()
            },
            ..Default::default()
        },
        client_b_config: CallConfig {
            audio: AudioConfig {
                input_name: "normal_12s".to_string(),
                initial_packet_size_ms,
                analysis_mode: AudioAnalysisMode::Chopped,
                generate_spectrogram: false,
                visqol_speech_analysis: true,
                visqol_audio_analysis: true,
                pesq_speech_analysis: true,
                plc_speech_analysis: true,
                enable_fec: !with_dred,
                dred_duration: if with_dred { 100 } else { 0 },
                dnn_weights_path: if with_dred {
                    "/data/deep_plc-dred-weights.bin".to_string()
                } else {
                    "".to_string()
                },
                ..Default::default()
            },
            ..Default::default()
        },
        ..Default::default()
    });

    test.run(
        GroupConfig {
            group_name: match with_dred {
                false => "changing_bandwidth_audio_test".to_string(),
                true => "changing_bandwidth_audio_test_with_dred".to_string(),
            },
            summary_report_columns: SummaryReportColumns {
                show_visqol_mos_speech: true,
                show_visqol_mos_audio: true,
                show_pesq_mos: true,
                show_plc_mos: true,
                show_video: false,
                show_send_stats: !with_dred,
                show_dred_stats: with_dred,
                ..Default::default()
            },
            ..Default::default()
        },
        test_cases.into(),
        vec![NetworkProfile::Custom(
            "limit_default".to_string(),
            vec![
                NetworkConfigWithOffset {
                    offset: Duration::from_secs(0),
                    network_config: NetworkConfig {
                        ..Default::default()
                    },
                },
                NetworkConfigWithOffset {
                    offset: Duration::from_secs(60),
                    network_config: NetworkConfig {
                        rate: 50,
                        ..Default::default()
                    },
                },
                NetworkConfigWithOffset {
                    offset: Duration::from_secs(120),
                    network_config: NetworkConfig {
                        rate: 25,
                        ..Default::default()
                    },
                },
                NetworkConfigWithOffset {
                    offset: Duration::from_secs(180),
                    network_config: NetworkConfig {
                        ..Default::default()
                    },
                },
            ],
        )],
    )
    .await?;

    Ok(())
}

async fn run_perf_test(test: &mut Test) -> Result<()> {
    test.run(
        GroupConfig {
            group_name: "perf_test".to_string(),
            // Show all the different measurements in the summary columns. Hide video.
            summary_report_columns: SummaryReportColumns {
                show_visqol_mos_speech: false,
                show_visqol_mos_audio: false,
                show_pesq_mos: false,
                show_plc_mos: false,
                show_video: false,
                ..Default::default()
            },
            ..Default::default()
        },
        vec![
            TestCaseConfig {
                test_case_name: "audio".to_string(),
                length_seconds: 60,
                save_media_files: false,
                client_a_config: CallConfig {
                    audio: AudioConfig {
                        input_name: "speaker_b".to_string(),
                        initial_packet_size_ms: 60,
                        generate_spectrogram: false,
                        visqol_speech_analysis: false,
                        visqol_audio_analysis: false,
                        pesq_speech_analysis: false,
                        plc_speech_analysis: false,
                        analysis_mode: AudioAnalysisMode::None,
                        ..Default::default()
                    },
                    ..Default::default()
                },
                client_b_config: CallConfig {
                    audio: AudioConfig {
                        input_name: "normal_phrasing".to_string(),
                        initial_packet_size_ms: 60,
                        enable_aec: true,
                        generate_spectrogram: false,
                        visqol_speech_analysis: false,
                        visqol_audio_analysis: false,
                        pesq_speech_analysis: false,
                        plc_speech_analysis: false,
                        ..Default::default()
                    },
                    ..Default::default()
                },
                iterations: 1,
                ..Default::default()
            },
            TestCaseConfig {
                test_case_name: "video".to_string(),
                length_seconds: 60,
                save_media_files: false,
                client_a_config: CallConfig {
                    audio: AudioConfig {
                        input_name: "speaker_b".to_string(),
                        initial_packet_size_ms: 60,
                        generate_spectrogram: false,
                        visqol_speech_analysis: false,
                        visqol_audio_analysis: false,
                        pesq_speech_analysis: false,
                        plc_speech_analysis: false,
                        analysis_mode: AudioAnalysisMode::None,
                        ..Default::default()
                    },
                    video: VideoConfig {
                        input_name: Some("ConferenceMotion_50fps@1280x720".to_string()),
                        ..Default::default()
                    },
                    ..Default::default()
                },
                client_b_config: CallConfig {
                    audio: AudioConfig {
                        input_name: "normal_phrasing".to_string(),
                        initial_packet_size_ms: 60,
                        enable_aec: true,
                        generate_spectrogram: false,
                        visqol_speech_analysis: false,
                        visqol_audio_analysis: false,
                        pesq_speech_analysis: false,
                        plc_speech_analysis: false,
                        ..Default::default()
                    },
                    video: VideoConfig {
                        input_name: Some("ConferenceMotion_50fps@1280x720".to_string()),
                        ..Default::default()
                    },
                    ..Default::default()
                },
                iterations: 1,
                ..Default::default()
            },
        ],
        vec![NetworkProfile::None],
    )
    .await?;

    Ok(())
}

/// Test the different PLC modes: NetEq, Opus, Opus Deep.
async fn run_plc_tests(test: &mut Test) -> Result<()> {
    let test_cases = [None, Some(0), Some(5)].map(|decoder_complexity| TestCaseConfig {
        test_case_name: format!(
            "plc_{}",
            decoder_complexity.map_or("None".to_string(), |c| c.to_string())
        ),
        client_a_config: CallConfig {
            audio: AudioConfig {
                input_name: "normal_phrasing".to_string(),
                generate_spectrogram: false,
                decoder_complexity,
                // Only used for Deep PLC (decoder complexity 5) tests.
                dnn_weights_path: "/data/deep_plc-dred-weights.bin".to_string(),
                ..Default::default()
            },
            ..Default::default()
        },
        client_b_config: CallConfig {
            audio: AudioConfig {
                input_name: "normal_phrasing".to_string(),
                visqol_speech_analysis: true,
                visqol_audio_analysis: true,
                pesq_speech_analysis: true,
                plc_speech_analysis: true,
                decoder_complexity,
                // Only used for Deep PLC (decoder complexity 5) tests.
                dnn_weights_path: "/data/deep_plc-dred-weights.bin".to_string(),
                ..Default::default()
            },
            ..Default::default()
        },
        iterations: 1,
        ..Default::default()
    });

    test.run(
        GroupConfig {
            group_name: "plc_tests".to_string(),
            summary_report_columns: SummaryReportColumns {
                show_visqol_mos_speech: true,
                show_visqol_mos_audio: true,
                show_pesq_mos: true,
                show_plc_mos: true,
                show_video: false,
                ..Default::default()
            },
            ..Default::default()
        },
        test_cases.into(),
        vec![
            NetworkProfile::None,
            NetworkProfile::SimpleLoss(10),
            NetworkProfile::SimpleLoss(20),
            NetworkProfile::SimpleLoss(30),
            NetworkProfile::SimpleLoss(40),
            NetworkProfile::SimpleLoss(50),
        ],
    )
    .await?;

    Ok(())
}

async fn run_dred_tests(test: &mut Test) -> Result<()> {
    let configs = [
        (60, true, 0, Some(0)),    // Before DRED with FEC and Opus PLC
        (60, false, 6, Some(5)),   // DRED 60ms
        (60, false, 12, Some(5)),  // DRED 120ms
        (60, false, 25, Some(5)),  // DRED 250ms
        (60, false, 50, Some(5)),  // DRED 500ms
        (60, false, 100, Some(5)), // DRED 1s
    ];

    let losses = [0, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50];

    let test_cases: Vec<_> = configs
        .iter()
        .flat_map(|&(initial_packet_size_ms, enable_fec, dred_duration, decoder_complexity)| {
            losses.iter().map(move |&loss| TestCaseConfig {
                test_case_name: format!(
                    "ptime_{initial_packet_size_ms}-fec_{enable_fec}-dred_duration_{dred_duration}-plc_{}-loss_{loss}",
                    decoder_complexity.map_or("None".to_string(), |c| c.to_string())
                ),
                length_seconds: 30,
                client_a_config: CallConfig {
                    audio: AudioConfig {
                        input_name: "normal_phrasing".to_string(),
                        generate_spectrogram: false,
                        visqol_speech_analysis: false,
                        visqol_audio_analysis: false,
                        pesq_speech_analysis: false,
                        plc_speech_analysis: false,
                        complexity: 9,
                        initial_packet_size_ms,
                        enable_fec,
                        dred_duration,
                        decoder_complexity,
                        // Force DRED to be encoded with the expected loss rate.
                        min_packet_loss_percent: if dred_duration > 0 { loss } else { 0 },
                        // Only used for Deep PLC (decoder complexity 5) or DRED tests.
                        dnn_weights_path: "/data/deep_plc-dred-weights.bin".to_string(),
                        ..Default::default()
                    },
                    profile: DeterministicLoss(loss),
                    ..Default::default()
                },
                client_b_config: CallConfig {
                    audio: AudioConfig {
                        input_name: "normal_phrasing".to_string(),
                        visqol_speech_analysis: true,
                        visqol_audio_analysis: true,
                        pesq_speech_analysis: true,
                        plc_speech_analysis: true,
                        complexity: 9,
                        initial_packet_size_ms,
                        enable_fec,
                        dred_duration,
                        decoder_complexity,
                        // Force DRED to be encoded with the expected loss rate.
                        min_packet_loss_percent: if dred_duration > 0 { loss } else { 0 },
                        // Only used for Deep PLC (decoder complexity 5) or DRED tests.
                        dnn_weights_path: "/data/deep_plc-dred-weights.bin".to_string(),
                        ..Default::default()
                    },
                    profile: DeterministicLoss(loss),
                    ..Default::default()
                },
                iterations: 3,
                ..Default::default()
            })
        })
        .collect();

    test.run(
        GroupConfig {
            group_name: "dred_tests".to_string(),
            summary_report_columns: SummaryReportColumns {
                show_visqol_mos_speech: true,
                show_visqol_mos_audio: true,
                show_pesq_mos: true,
                show_plc_mos: true,
                show_video: false,
                show_send_stats: false,
                show_dred_stats: true,
                ..Default::default()
            },
            ..Default::default()
        },
        test_cases,
        vec![NetworkProfile::None],
    )
    .await?;

    Ok(())
}

#[tokio::main]
async fn main() -> Result<()> {
    let args = Args::parse();

    println!("Starting the call simulator...");

    let mut root_path = env::current_dir()?;
    root_path.push(args.root);
    println!("  Using root path: {}", root_path.display());
    env::set_current_dir(&root_path)?;

    if args.build {
        build_images(!args.skip_visqol_mos_build).await?;
    }

    if args.clean {
        clean_up(vec![
            "client_a",
            "client_b",
            "signaling_server",
            "turn",
            "tcpdump_client_a",
            "tcpdump_client_b",
            "visqol",
        ])
        .await?;
        clean_network().await?;
    }

    let client_profiles = args
        .client_profile_dir
        .map_or_else(generate_client_profiles, |client_profile_dir| {
            get_client_profiles(&client_profile_dir)
        });

    let mut test_sets = args.test_sets;
    if test_sets.is_empty() {
        // For quick testing, change this to the name of your test case.
        test_sets.push("baseline_with_dred".to_string());
    }

    let direct_call_config = CallTypeConfig::Direct;
    let group_call_config = CallTypeConfig::Group {
        sfu_url: SFU_URL.to_owned(),
        group_name: args.group_name,
    };

    for test_set_name in test_sets {
        let (call_type_config, test_set_name) =
            if let Some(name) = test_set_name.strip_prefix("group_") {
                (group_call_config.clone(), name.to_owned())
            } else {
                (direct_call_config.clone(), test_set_name)
            };
        println!(
            "Running test set {} as call type {:?}",
            test_set_name, call_type_config,
        );
        let test = &mut Test::new(
            &root_path,
            &args.output_dir,
            &args.media_dir,
            &args.data_dir,
            &test_set_name,
            client_profiles.clone(),
            call_type_config,
            args.profile,
        )?;
        match test_set_name.as_str() {
            "minimal_example" => run_minimal_example(test).await?,
            "baseline" => run_baseline(test, false, false).await?,
            "baseline_with_dred" => run_baseline(test, false, true).await?,
            "baseline_with_video" => run_baseline(test, true, false).await?,
            "bursty_loss_test" => run_bursty_loss_test(test, false, false).await?,
            "bursty_loss_test_with_dred" => run_bursty_loss_test(test, false, true).await?,
            "bursty_loss_test_with_video" => run_bursty_loss_test(test, true, false).await?,
            "deterministic_loss_test" => run_deterministic_loss_test(test, false, false).await?,
            "deterministic_loss_test_with_dred" => {
                run_deterministic_loss_test(test, false, true).await?
            }
            "deterministic_loss_test_with_video" => {
                run_deterministic_loss_test(test, true, false).await?
            }
            "relay_tests" => run_relay_tests(test).await?,
            "turn_long_tests" => run_turn_long_tests(test).await?,
            "video_send_over_bandwidth" => run_video_send_over_bandwidth(test).await?,
            "video_compare_vp8_vs_vp9" => {
                run_video_compare_vp8_vs_vp9(test, &vec![1000, 2000]).await?
            }
            "changing_bandwidth_audio_test" => {
                run_changing_bandwidth_audio_test(test, false).await?
            }
            "changing_bandwidth_audio_test_with_dred" => {
                run_changing_bandwidth_audio_test(test, true).await?
            }
            "profiling_suite" => run_perf_test(test).await?,
            "plc_tests" => run_plc_tests(test).await?,
            "dred_tests" => run_dred_tests(test).await?,
            _ => panic!("unknown test set \"{test_set_name}\""),
        }
        test.report().await?;
    }

    Ok(())
}

fn generate_client_profiles() -> Vec<ClientProfile> {
    let now = SystemTime::now();
    config::generate_client_profiles(2, &group_auth_key_gen(), now)
}

fn get_client_profiles(dir_path: &str) -> Vec<ClientProfile> {
    println!("Looking for client profiles in `{}`", dir_path);
    let files = std::fs::read_dir(dir_path)
        .expect("Failed to list client profile directory")
        .map(|entry| entry.unwrap().path())
        .filter(|p| p.extension().is_some_and(|ext| ext == "json"))
        .sorted();
    println!("Found {} client profiles config files", files.len());
    files.map(|path| get_client_profile(&path)).collect()
}

fn get_client_profile(path: &Path) -> ClientProfile {
    if let Ok(file) = File::open(path) {
        serde_json::from_reader(file).expect("client config file to be in JSON format")
    } else {
        panic!("Failed to find client config file `{}`", path.display());
    }
}
